package org.example.lab;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    private static HelloApplication instance;
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 500, 500);
        stage.setTitle("My Locations");
        stage.setScene(scene);
        stage.show();

        instance = this;  // Set the instance variable
        HelloController controller = fxmlLoader.getController();
        controller.setApplication(this);
    }
    public static HelloApplication getInstance() {
        return instance;
    }

    public static void main(String[] args) {
        launch();
    }

    public void loadVolcanoView() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("volcano-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),500, 500);
        Stage stage = new Stage();
        stage.setTitle("Volcano View");
        stage.setScene(scene);
        stage.show();
    }

    public void loadHawaiiView() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hawaii-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),500, 500);
        Stage stage = new Stage();
        stage.setTitle(" Visit Hawaii");
        stage.setScene(scene);
        stage.show();
    }

    public void loadOceanView() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("ocean-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),500, 500);
        Stage stage = new Stage();
        stage.setTitle("In the Ocean");
        stage.setScene(scene);
        stage.show();
    }
}