package org.example.lab;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.application.Application;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloController extends Application{
    private Application application;  // Add this field
    @FXML
    private Label welcomeText;

    @FXML
    private ImageView imageView1;

    @FXML
    private ImageView imageView2;

    @FXML
    private ImageView imageView3;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    public void setApplication(Application application) {
        this.application = application;
    }

    @FXML
    protected void checkVolcanoClicked() throws IOException {
        ((HelloApplication) HelloApplication.getInstance()).loadVolcanoView();
    }

    @FXML
    protected void checkHawaiiClicked() throws IOException {
        ((HelloApplication) HelloApplication.getInstance()).loadHawaiiView();
    }

    @FXML
    protected void checkOceanClicked() throws IOException {
        ((HelloApplication) HelloApplication.getInstance()).loadOceanView();
    }


    // You can load images in the initialize method or any other appropriate method
    @FXML
    public void initialize() {
        Image image1 = new Image(getClass().getResourceAsStream("volcano.jpg"));
        imageView1.setImage(image1);

        Image image2 = new Image(getClass().getResourceAsStream("Hawaii.jpg"));
        imageView2.setImage(image2);

        Image image3 = new Image(getClass().getResourceAsStream("ocean.jpg"));
        imageView3.setImage(image3);
    }

    @java.lang.Override
    public void start(Stage primaryStage) throws Exception {

    }
}
