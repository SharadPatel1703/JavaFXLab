package org.example.lab;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class VolcanoController {

    @FXML
    private Button backButton; // Add this line to declare the backButton

    @FXML
    private void goToHelloView() throws IOException {
        HelloApplication.getInstance().start(new Stage());
        // Close the current stage (VolcanoView)
        ((Stage) backButton.getScene().getWindow()).close();
    }
}

